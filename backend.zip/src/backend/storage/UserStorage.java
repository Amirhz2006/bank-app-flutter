package backend.storage;

import backend.model.User;
import java.io.*;

public class UserStorage {
    File file;

    public UserStorage(String path) {
        file = new File(path);
    }

    private void ensure() throws Exception {
        if (!file.exists()) {
            file.getParentFile().mkdirs();
            file.createNewFile();
        }
    }

    public void save(User u) throws Exception {
        ensure();
        if (find(u.username) != null)
            throw new Exception("USER_EXISTS");

        try (FileWriter fw = new FileWriter(file, true)) {
            fw.write(u.username + "," + u.password + "," + u.name + "\n");
        }
    }

    public User find(String u) throws Exception {
        ensure();
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String l;
            while ((l = br.readLine()) != null) {
                String[] p = l.split(",");
                if (p[0].equals(u))
                    return new User(p[0], p[1], p[2]);
            }
        }
        return null;
    }

    public void update(User u) throws Exception {
        ensure();
        File tmp = new File("tmp.txt");

        try (
                BufferedReader br = new BufferedReader(new FileReader(file));
                FileWriter fw = new FileWriter(tmp)
        ) {
            String l;
            while ((l = br.readLine()) != null) {
                String[] p = l.split(",");
                if (p[0].equals(u.username))
                    fw.write(u.username + "," + u.password + "," + u.name + "\n");
                else
                    fw.write(l + "\n");
            }
        }
        file.delete();
        tmp.renameTo(file);
    }
}