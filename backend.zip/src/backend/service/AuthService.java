package backend.service;

import backend.model.User;
import backend.storage.UserStorage;

public class AuthService {

    private final UserStorage storage;

    public AuthService(UserStorage storage) {
        this.storage = storage;
    }
    public void register(String username, String password, String name) throws Exception {
        if (username == null || username.isEmpty())
            throw new Exception("INVALID_USERNAME");

        if (password == null || password.isEmpty())
            throw new Exception("INVALID_PASSWORD");

        if (name == null || name.isEmpty())
            throw new Exception("INVALID_NAME");

        User u = new User(username, password, name);
        storage.save(u);
    }
    public void login(String username, String password) throws Exception {
        User u = storage.find(username);

        if (u == null)
            throw new Exception("USER_NOT_FOUND");

        if (!u.password.equals(password))
            throw new Exception("WRONG_PASSWORD");
    }

    public void editProfile(String username, String newName) throws Exception {
        if (newName == null || newName.isEmpty())
            throw new Exception("INVALID_NAME");

        User u = storage.find(username);
        if (u == null)
            throw new Exception("USER_NOT_FOUND");

        u.name = newName;
        storage.update(u);
    }
}
