package backend.service;

import backend.model.Account;
import backend.storage.AccountStorage;
import java.util.Random;

public class AccountService {
    AccountStorage storage;

    public AccountService(AccountStorage s) {
        storage = s;
    }

    public Account create(String owner, long bal) throws Exception {
        String acc = "" + System.currentTimeMillis();
        String card = "" + (1000000000000000L + new Random().nextLong()%100000000000000L);
        String iban = "IR" + acc;

        Account a = new Account(acc, owner, bal, card, iban);
        storage.save(a);
        return a;
    }

    public void deposit(String acc, long amount) throws Exception {
        Account a = storage.findByAccount(acc);
        a.balance += amount;
        storage.update(a);
    }

    public void withdraw(String acc, long amount) throws Exception {
        Account a = storage.findByAccount(acc);
        if (a.balance < amount)
            throw new Exception("INSUFFICIENT");
        a.balance -= amount;
        storage.update(a);
    }
}
