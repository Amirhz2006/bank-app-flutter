FINAL BANK PROJECT - BACKEND
Pure Java, File-based, Test-driven
