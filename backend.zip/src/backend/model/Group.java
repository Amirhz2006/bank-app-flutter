package backend.model;

import java.util.*;

public class Group {
    public String id;
    public String name;
    public List<String> members = new ArrayList<>();

    public Group(String i, String n) {
        id = i;
        name = n;
    }
}
