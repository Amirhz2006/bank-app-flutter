package backend.model;

public class Account {
    public String accountNumber;
    public String owner;
    public long balance;
    public String cardNumber;
    public String iban;

    public Account(String a, String o, long b, String c, String i) {
        accountNumber = a;
        owner = o;
        balance = b;
        cardNumber = c;
        iban = i;
    }
}
