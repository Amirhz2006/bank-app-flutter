package backend.test;

import backend.service.*;
import backend.storage.*;
import backend.model.*;
import java.nio.file.Files;
import java.nio.file.Paths;

public class GroupServiceTest {
    public static void main(String[] args) {
        try {
            // پاک کردن فایل‌های قبلی
            Files.deleteIfExists(Paths.get("data/groups.txt"));
            Files.deleteIfExists(Paths.get("data/accounts.txt"));
            Files.deleteIfExists(Paths.get("data/transactions.txt"));
            Files.deleteIfExists(Paths.get("data/users.txt"));
            System.out.println("Previous data files deleted.");

            GroupStorage gs = new GroupStorage("data/groups.txt");
            AccountStorage as = new AccountStorage("data/accounts.txt");
            TransactionStorage ts = new TransactionStorage("data/transactions.txt");
            UserStorage us = new UserStorage("data/users.txt");

            AccountService accService = new AccountService(as);
            GroupService groupService = new GroupService(gs, as, ts);
            AuthService authService = new AuthService(us);

            // ثبت نام کاربران
            System.out.println("Registering users...");
            authService.register("ali", "123", "Ali");
            authService.register("reza", "123", "Reza");
            System.out.println("✓ Users registered");

            // ایجاد حساب
            System.out.println("Creating accounts...");
            Account ali = accService.create("ali", 10000);
            accService.create("reza", 0);
            System.out.println("✓ Accounts created");

            // ایجاد گروه
            System.out.println("Creating group...");
            Group g = groupService.createGroup("Trip", "ali");
            groupService.addMember(g.id, "reza");
            System.out.println("✓ Group created with members");

            // اضافه کردن هزینه
            System.out.println("Adding expense...");
            groupService.addExpense(g.id, ali.accountNumber, 6000);
            System.out.println("✓ Expense added");

            // بررسی موجودی
            Account updatedAli = as.findByAccount(ali.accountNumber);
            System.out.println("Ali balance after expense: " + updatedAli.balance);

            if (updatedAli.balance != 4000) {
                throw new RuntimeException("BALANCE NOT UPDATED CORRECTLY: expected 4000, got " + updatedAli.balance);
            }

            Group stored = gs.find(g.id);
            if (stored == null) {
                throw new RuntimeException("GROUP NOT STORED CORRECTLY: group is null");
            }
            if (stored.members.size() != 2) {
                throw new RuntimeException("GROUP NOT STORED CORRECTLY: expected 2 members, got " + stored.members.size());
            }

            System.out.println("\n✅ GROUP SERVICE TEST PASSED");
        } catch (Exception e) {
            System.err.println("\n❌ GROUP SERVICE TEST FAILED: " + e.getMessage());
            e.printStackTrace();
        }
    }
}