package backend.test;

import backend.service.*;
import backend.storage.*;
import backend.model.*;
import java.nio.file.Files;
import java.nio.file.Paths;

public class TransferServiceTest {
    public static void main(String[] args) throws Exception {
        Files.deleteIfExists(Paths.get("data/accounts.txt"));
        System.out.println("Previous data deleted.");

        AccountStorage st = new AccountStorage("data/accounts.txt");
        AccountService as = new AccountService(st);
        TransferService ts = new TransferService(st);

        Account a = as.create("ali", 5000);
        Account b = as.create("reza", 1000);

        System.out.println("Before transfer:");
        System.out.println("Ali balance: " + a.balance);
        System.out.println("Reza balance: " + b.balance);

        ts.cardToCard(a.accountNumber, b.accountNumber, 2000);
        a = st.findByAccount(a.accountNumber);
        b = st.findByAccount(b.accountNumber);

        System.out.println("\nAfter transfer:");
        System.out.println("Ali balance: " + a.balance);
        System.out.println("Reza balance: " + b.balance);

        if (a.balance == 3000 && b.balance == 3000) {
            System.out.println("\n✅ TRANSFER TEST PASSED");
        } else {
            throw new RuntimeException("Transfer failed!");
        }
    }
}