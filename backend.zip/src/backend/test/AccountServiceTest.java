package backend.test;

import backend.service.AccountService;
import backend.storage.AccountStorage;
import backend.model.Account;
import java.nio.file.Files;
import java.nio.file.Paths;

public class AccountServiceTest {
    public static void main(String[] args) throws Exception {
        Files.deleteIfExists(Paths.get("data/accounts.txt"));
        System.out.println("Previous account data deleted.");

        AccountService s = new AccountService(new AccountStorage("data/accounts.txt"));

        Account a = s.create("ali", 1000);
        System.out.println("Account created: " + a.accountNumber);

        s.deposit(a.accountNumber, 500);
        System.out.println("Deposited 500");

        s.withdraw(a.accountNumber, 300);
        System.out.println("Withdrawn 300");

        System.out.println("\n✅ ACCOUNT TEST PASSED");
    }
}