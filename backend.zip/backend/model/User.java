package backend.model;

public class User {
    public String username;
    public String password;
    public String name;

    public User(String u, String p, String n) {
        username = u;
        password = p;
        name = n;
    }
}
