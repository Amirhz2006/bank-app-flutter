package backend.model;

public class Transaction {
    public String from;
    public String to;
    public long amount;
    public String type;

    public Transaction(String f, String t, long a, String ty) {
        from = f;
        to = t;
        amount = a;
        type = ty;
    }
}
