package backend.service;

import backend.model.*;
import backend.storage.*;

import java.util.UUID;

public class GroupService {

    private final GroupStorage groupStorage;
    private final AccountStorage accountStorage;
    private final TransactionStorage transactionStorage;

    public GroupService(GroupStorage gs, AccountStorage as, TransactionStorage ts) {
        this.groupStorage = gs;
        this.accountStorage = as;
        this.transactionStorage = ts;
    }

    public Group createGroup(String name, String creator) throws Exception {
        Group g = new Group(UUID.randomUUID().toString(), name);
        g.members.add(creator);
        groupStorage.save(g);
        return g;
    }

    public void addMember(String groupId, String username) throws Exception {
        Group g = groupStorage.find(groupId);
        if (g == null) {
            throw new RuntimeException("GROUP NOT FOUND");
        }
        if (!g.members.contains(username)) {
            g.members.add(username);
            groupStorage.update(g);
        }
    }
    public void addExpense(String groupId, String payer, long amount) throws Exception {
        if (amount <= 0) throw new Exception("INVALID_AMOUNT");

        Group g = groupStorage.find(groupId);
        if (g == null)
            throw new RuntimeException("GROUP NOT FOUND");
            Account acc = accountStorage.findByAccount(payer);
        if (acc == null)
            throw new RuntimeException("ACCOUNT_FOR_PAYER_NOT_FOUND");

        if (acc.balance < amount)
            throw new RuntimeException("INSUFFICIENT_BALANCE");

        acc.balance -= amount;
        accountStorage.update(acc);

        Transaction t = new Transaction(payer, g.id, amount, "GROUP:" + g.name);
        transactionStorage.save(t);
    }
}