package backend.service;

import backend.storage.AccountStorage;
import backend.model.Account;

public class TransferService {
    AccountStorage storage;

    public TransferService(AccountStorage s) {
        storage = s;
    }

    public void cardToCard(String from, String to, long amt) throws Exception {
        Account a = storage.findByAccount(from);
        Account b = storage.findByAccount(to);

        if (a.balance < amt)
            throw new Exception("NO_MONEY");

        a.balance -= amt;
        b.balance += amt;

        storage.update(a);
        storage.update(b);
    }
}