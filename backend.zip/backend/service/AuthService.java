package backend.service;

import backend.model.User;
import backend.storage.UserStorage;

public class AuthService {

    private final UserStorage storage;

    public AuthService(UserStorage storage) {
        this.storage = storage;
    }

    public void register(String username, String password, String name) throws Exception {
        if (username == null || username.trim().isEmpty())
            throw new Exception("INVALID_USERNAME");

        if (password == null || password.trim().isEmpty())
            throw new Exception("INVALID_PASSWORD");

        if (name == null || name.trim().isEmpty())
            throw new Exception("INVALID_NAME");

        if (password.length() < 4)
            throw new Exception("PASSWORD_TOO_SHORT");

        User u = new User(username.trim(), password, name.trim());
        storage.save(u);
    }

    public User login(String username, String password) throws Exception {
        User u = storage.find(username);

        if (u == null)
            throw new Exception("USER_NOT_FOUND");

        if (!u.password.equals(password))
            throw new Exception("WRONG_PASSWORD");

        return u;
    }

    public void editUsername(String oldUsername, String newUsername) throws Exception {
        if (newUsername == null || newUsername.trim().isEmpty())
            throw new Exception("INVALID_USERNAME");

        User existingUser = storage.find(newUsername);
        if (existingUser != null)
            throw new Exception("USERNAME_ALREADY_EXISTS");

        User u = storage.find(oldUsername);
        if (u == null)
            throw new Exception("USER_NOT_FOUND");

        storage.delete(oldUsername);
        u.username = newUsername.trim();
        storage.save(u);
    }

    public void editPassword(String username, String oldPassword, String newPassword) throws Exception {
        if (newPassword == null || newPassword.trim().isEmpty())
            throw new Exception("INVALID_PASSWORD");

        if (newPassword.length() < 4)
            throw new Exception("PASSWORD_TOO_SHORT");

        User u = storage.find(username);
        if (u == null)
            throw new Exception("USER_NOT_FOUND");

        if (!u.password.equals(oldPassword))
            throw new Exception("WRONG_PASSWORD");

        u.password = newPassword;
        storage.update(u);
    }

    public void editProfile(String username, String newName) throws Exception {
        if (newName == null || newName.trim().isEmpty())
            throw new Exception("INVALID_NAME");

        User u = storage.find(username);
        if (u == null)
            throw new Exception("USER_NOT_FOUND");

        u.name = newName.trim();
        storage.update(u);
    }

    public void deleteAccount(String username, String password) throws Exception {
        User u = storage.find(username);

        if (u == null)
            throw new Exception("USER_NOT_FOUND");

        if (!u.password.equals(password))
            throw new Exception("WRONG_PASSWORD");

        storage.delete(username);
    }
}