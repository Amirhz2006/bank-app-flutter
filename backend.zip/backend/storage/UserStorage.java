package backend.storage;

import backend.model.User;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class UserStorage {
    private final File file;

    public UserStorage(String path) {
        this.file = new File(path);
    }

    private void ensure() throws IOException {
        if (!file.exists()) {
            File parentDir = file.getParentFile();
            if (parentDir != null && !parentDir.exists()) {
                if (!parentDir.mkdirs()) {
                    throw new IOException("Failed to create directories: " + parentDir.getPath());
                }
            }
            if (!file.createNewFile()) {
                throw new IOException("Failed to create file: " + file.getPath());
            }
        }
    }

    public void save(User u) throws IOException, Exception {
        ensure();
        if (find(u.username) != null) {
            throw new Exception("USER_EXISTS");
        }

        try (FileWriter fw = new FileWriter(file, true)) {
            fw.write(u.username + "," + u.password + "," + u.name + "\n");
        }
    }

    public User find(String username) throws IOException {
        ensure();
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                String[] parts = line.split(",");
                if (parts.length >= 3 && parts[0].equals(username)) {
                    return new User(parts[0], parts[1], parts[2]);
                }
            }
        }
        return null;
    }

    public void update(User u) throws IOException {
        ensure();
        File tempFile = new File(file.getParentFile(), "tmp_user_" + System.currentTimeMillis() + ".txt");

        boolean found = false;
        try (
                BufferedReader br = new BufferedReader(new FileReader(file));
                FileWriter fw = new FileWriter(tempFile)
        ) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                String[] parts = line.split(",");
                if (parts.length >= 3 && parts[0].equals(u.username)) {
                    fw.write(u.username + "," + u.password + "," + u.name + "\n");
                    found = true;
                } else {
                    fw.write(line + "\n");
                }
            }

            if (!found) {
                fw.write(u.username + "," + u.password + "," + u.name + "\n");
            }
        }

        if (!file.delete()) {
            throw new IOException("Failed to delete original file");
        }

        if (!tempFile.renameTo(file)) {
            throw new IOException("Failed to rename temp file to original file");
        }
    }

    public void delete(String username) throws IOException {
        ensure();
        File tempFile = new File(file.getParentFile(), "tmp_user_" + System.currentTimeMillis() + ".txt");

        try (
                BufferedReader br = new BufferedReader(new FileReader(file));
                FileWriter fw = new FileWriter(tempFile)
        ) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                String[] parts = line.split(",");
                if (!parts[0].equals(username)) {
                    fw.write(line + "\n");
                }
            }
        }

        if (!file.delete()) {
            throw new IOException("Failed to delete original file");
        }

        if (!tempFile.renameTo(file)) {
            throw new IOException("Failed to rename temp file to original file");
        }
    }

    public List<User> findAll() throws IOException {
        ensure();
        List<User> users = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                String[] parts = line.split(",");
                if (parts.length >= 3) {
                    users.add(new User(parts[0], parts[1], parts[2]));
                }
            }
        }
        return users;
    }
}