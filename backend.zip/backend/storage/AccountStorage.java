package backend.storage;

import backend.model.Account;
import java.io.*;

public class AccountStorage {
    File file;

    public AccountStorage(String path) {
        file = new File(path);
    }

    private void ensure() throws Exception {
        if (!file.exists()) {
            file.getParentFile().mkdirs();
            file.createNewFile();
        }
    }

    public void save(Account a) throws Exception {
        ensure();
        try (FileWriter fw = new FileWriter(file, true)) {
            fw.write(a.accountNumber + "," + a.owner + "," +
                    a.balance + "," + a.cardNumber + "," + a.shaba + "\n");
        }
    }

    public Account findByAccount(String acc) throws Exception {
        ensure();
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String l;
            while ((l = br.readLine()) != null) {
                String[] p = l.split(",");
                if (p[0].equals(acc))
                    return new Account(p[0], p[1],
                            Long.parseLong(p[2]), p[3], p[4]);
            }
        }
        return null;
    }

    public void update(Account a) throws Exception {
        ensure();
        File tmp = new File("tmp2.txt");

        try (
                BufferedReader br = new BufferedReader(new FileReader(file));
                FileWriter fw = new FileWriter(tmp)
        ) {
            String l;
            while ((l = br.readLine()) != null) {
                String[] p = l.split(",");
                if (p[0].equals(a.accountNumber))
                    fw.write(a.accountNumber + "," + a.owner + "," +
                            a.balance + "," + a.cardNumber + "," + a.shaba + "\n");
                else
                    fw.write(l + "\n");
            }
        }
        file.delete();
        tmp.renameTo(file);
    }
}