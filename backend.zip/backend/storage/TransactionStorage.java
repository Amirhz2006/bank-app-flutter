package backend.storage;

import backend.model.Transaction;
import java.io.*;

public class TransactionStorage {
    private final File file;

    public TransactionStorage(String path) {
        this.file = new File(path);
    }

    private void ensure() throws Exception {
        if (!file.exists()) {
            file.getParentFile().mkdirs();
            file.createNewFile();
        }
    }

    public void save(Transaction t) throws Exception {
        ensure();
        try (FileWriter fw = new FileWriter(file, true)) {
            fw.write(
                    t.from + "," +
                            t.to + "," +
                            t.amount + "," +
                            t.type + "\n"
            );
        }
    }
}