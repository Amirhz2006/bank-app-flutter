package backend.storage;

import backend.model.Group;
import java.io.*;
import java.util.*;

public class GroupStorage {

    private final File file;

    public GroupStorage(String path) {
        this.file = new File(path);
    }

    private void ensure() throws Exception {
        if (!file.exists()) {
            file.getParentFile().mkdirs();
            file.createNewFile();
        }
    }

    public void save(Group g) throws Exception {
        ensure();
        try (FileWriter fw = new FileWriter(file, true)) {
            fw.write(serialize(g) + "\n");
        }
    }

    public Group find(String id) throws Exception {
        ensure();
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String l;
            while ((l = br.readLine()) != null) {
                Group g = deserialize(l);
                if (g.id.equals(id))
                    return g;
            }
        }
        return null;
    }

    public void update(Group g) throws Exception {
        ensure();
        File tmp = new File(file.getParent(), "tmp_groups.txt");

        try (
                BufferedReader br = new BufferedReader(new FileReader(file));
                FileWriter fw = new FileWriter(tmp)
        ) {
            String l;
            while ((l = br.readLine()) != null) {
                Group cur = deserialize(l);
                if (cur.id.equals(g.id))
                    fw.write(serialize(g) + "\n");
                else
                    fw.write(l + "\n");
            }
        }
        file.delete();
        tmp.renameTo(file);
    }

    private String serialize(Group g) {
        return g.id + "," + g.name + "," + String.join(";", g.members);
    }

    private Group deserialize(String line) {
        String[] p = line.split(",", -1);
        Group g = new Group(p[0], p[1]);
        if (p.length > 2 && !p[2].isEmpty())
            g.members.addAll(Arrays.asList(p[2].split(";")));
        return g;
    }
}