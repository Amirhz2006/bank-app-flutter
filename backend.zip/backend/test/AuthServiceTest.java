package backend.test;

import backend.service.AuthService;
import backend.storage.UserStorage;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.logging.Logger;

public class AuthServiceTest {
    private static final Logger LOGGER = Logger.getLogger(AuthServiceTest.class.getName());

    public static void main(String[] args) {
        try {
            Files.deleteIfExists(Paths.get("data/users.txt"));
            System.out.println("Previous data file deleted.");

            UserStorage us = new UserStorage("data/users.txt");
            AuthService auth = new AuthService(us);

            System.out.println("Registering user 'ali'...");
            auth.register("ali", "1234", "Ali");
            System.out.println("✓ User registered successfully");

            System.out.println("Logging in with correct password...");
            auth.login("ali", "1234");
            System.out.println("✓ Login successful");

            boolean failed = false;
            try {
                System.out.println("Testing wrong password...");
                auth.login("ali", "wrong");
            } catch (Exception e) {
                failed = true;
                System.out.println("✓ Wrong password correctly rejected: " + e.getMessage());
            }
            if (!failed) {
                throw new RuntimeException("WRONG PASSWORD SHOULD FAIL");
            }

            System.out.println("Editing profile...");
            auth.editProfile("ali", "Ali Reza");
            System.out.println("✓ Profile updated successfully");

            System.out.println("\nAUTH SERVICE TEST PASSED");

        } catch (Exception e) {
            System.err.println("\nAUTH SERVICE TEST FAILED: " + e.getMessage());
            e.printStackTrace();
        }
    }
}